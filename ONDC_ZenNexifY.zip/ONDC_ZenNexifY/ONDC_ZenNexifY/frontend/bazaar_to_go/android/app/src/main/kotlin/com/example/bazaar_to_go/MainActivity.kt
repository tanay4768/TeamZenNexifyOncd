package com.example.bazaar_to_go

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
